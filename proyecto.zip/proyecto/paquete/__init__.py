# Inicializa el paquete
print(f"El paquete llamado '{__name__}' ha sido inicializado.")

# Función propia del paquete
def descripcion():
    print("Soy el paquete.")

# Importaciones internas para acceso directo
import paquete.modulo1
import paquete.modulo2

# Control de importación con *
__all__ = ['modulo1', 'modulo2']
