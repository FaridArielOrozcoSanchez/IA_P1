def descripcion():
    print("Soy el módulo 1.")

def suma(a, b):
    return a + b
