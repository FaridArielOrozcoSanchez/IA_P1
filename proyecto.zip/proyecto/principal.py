# Importación directa de módulos
import paquete.modulo1
import paquete.modulo2

paquete.modulo1.descripcion()  # Soy el módulo 1.
paquete.modulo2.descripcion()  # Soy el módulo 2.

# Importación de función específica
from paquete.modulo1 import suma
print("Suma:", suma(10, 30))  # Suma: 40

# Uso de alias para simplificar
import paquete.modulo1 as md1
import paquete.modulo2 as md2

md1.descripcion()  # Soy el módulo 1.
md2.descripcion()  # Soy el módulo 2.

# Importación desde subpaquete
import paquete.subpaquete.modulo3 as md3
import paquete.subpaquete.modulo4 as md4

md3.descripcion()  # Soy el módulo 3.
md4.descripcion()  # Soy el módulo 4.

# Importación del paquete completo
import paquete as pqt
pqt.descripcion()  # Soy el paquete.

# Acceso a módulo desde __init__.py
pqt.modulo1.descripcion()  # Soy el módulo 1.

# Importación con *
from paquete import *
modulo1.descripcion()  # Soy el módulo 1.
modulo2.descripcion()  # Soy el módulo 2.
